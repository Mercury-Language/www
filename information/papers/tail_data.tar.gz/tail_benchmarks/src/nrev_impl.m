%   nrev
% %   David H. D. Warren
%
%   "naive"-reverse a list of 30 integers

:- module nrev_impl.

:- interface.

:- import_module list.

:- pred nrev(list(T), list(T)).
:- mode nrev(in, out) is det.

:- implementation.

nrev([], []).
nrev([X|L0], L) :-
	nrev(L0, L1),
	app(L1, [X], L).

:- pred app(list(T), list(T), list(T)).
:- mode app(in, in, out) is det.

app([X|L1], L2, [X|L3]) :-	
	app(L1, L2, L3).
app([], L, L).
