:- module sumdbl.

:- interface.

:- pred sumdbl is semidet.

:- implementation.

:- import_module sumdbl_impl, run.
:- import_module list.

sumdbl :-
	data(D),
	sumdbl(D, A, B),
	use(A),
	use(B).
