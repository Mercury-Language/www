:- module sumdbl_impl.

:- interface.

:- import_module list, int.

:- pred sumdbl(list(int), int, list(int)).
:- mode sumdbl(in, out, out) is det.

:- implementation.

% :- assertion all [A,B,C] ( C = A+B <=> C = B+A ).

sumdbl([], 0, []).
sumdbl([H|T], S, D) :-
	sumdbl(T, S0, D0),
	S = S0 + H,
	D = [2*H | D0].
