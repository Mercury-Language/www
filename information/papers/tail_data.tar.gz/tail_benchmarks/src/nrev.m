:- module nrev.

:- interface.

:- pred nrev is semidet.

:- implementation.

:- import_module nrev_impl, run.
:- import_module list.

nrev :-
	data(D),
	nrev(D, L),
	use(L).
