:- module append_impl.

:- interface.

:- import_module list.

:- pred app(list(T), list(T), list(T)).
:- mode app(in, in, out) is det.

:- implementation.

app([], Ys, Ys).
app([X|Xs], Ys, [X|Zs]) :-
	app(Xs, Ys, Zs).
