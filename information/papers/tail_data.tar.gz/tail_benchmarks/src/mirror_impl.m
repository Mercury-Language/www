:- module mirror_impl.

:- interface.

:- import_module list.

:- pred mirror(list(T), list(T)).
:- mode mirror(in, out) is det.

:- implementation.

mirror([], []).
mirror([H|T], [H|M1]) :-
	mirror(T, M0),
	app(M0, [H], M1).
	% M = [H|M1].

/*
:- promise all [A,B,C,ABC]
	(
		(some[AB] app(A,B,AB), app(AB,C,ABC))
	<=>
		(some[BC] app(B,C,BC), app(A,BC,ABC))
	).
*/

:- pred app(list(T)::in, list(T)::in, list(T)::out) is det.

app([], Ys, Ys).
app([X|Xs], Ys, [X|Zs]) :-
	app(Xs, Ys, Zs).
