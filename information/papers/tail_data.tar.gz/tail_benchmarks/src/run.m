:- module run.

:- interface.

:- import_module list, int, io.

:- pred main(io__state::di, io__state::uo) is cc_multi.

:- pred use(T::in) is semidet.

:- pred data(list(int)).
:- mode data(out) is det.

:- implementation.

:- import_module benchmarking, list, string, int, std_util.

	% The imports which are modules to be benchmarked.
:- import_module 
	append,
	mirror,
	nrev,
	reverse_double,
	sumdbl,
	sumlist.

main -->
	io__command_line_arguments(Args), 
	(
		{ Args = ["-n", Arg2] },
		{ string__to_int(Arg2, Iterations0) }
	->
		{ Iterations = Iterations0 }
	;
		{ Iterations = 1000 }
	),
	run_benchmark_list(Iterations, benchmark_list).

:- pred run_benchmark_list(int::in, list(benchmark)::in(list_skel(benchmark)), 
		io__state::di, io__state::uo) is cc_multi.

run_benchmark_list(_, []) --> [].
run_benchmark_list(Iterations,
		[benchmark(Name, Factor, Closure) | Benchmarks]) -->
	run_benchmark(Factor*Iterations, Name, Closure),
	run_benchmark_list(Iterations, Benchmarks).

:- pred run_benchmark(int, string, pred, io__state, io__state). 
:- mode run_benchmark(in, in, (pred) is semidet, di, uo) is cc_multi.

run_benchmark(Iterations, Name, Closure) -->
	{ CallClosure = 
		( pred(_Input::in, Output::out) is det :-
			( call(Closure) ->
				Output = 1
			;
				Output = 0
			)
		) },
	{ benchmark_det(CallClosure, 0, _, Iterations, Time) },
	io__write_string(Name),
	io__write_string("\t"),
	io__write_int(Time),
	io__write_string("\t"),
	io__write_int(Iterations),
	io__write_string(" iterations"),
	io__nl,
	io__flush_output,
	collect.

:- pred collect(io__state::di, io__state::uo) is det.
:- pragma c_code(collect(IO0::di, IO::uo),
"{
	IO = IO0;
#ifdef CONSERVATIVE_GC
	GC_gcollect();
#endif
}").

:- func benchmark_list = list(benchmark).
:- mode benchmark_list = list_skel_out(benchmark).

:- type factor == int.
:- type benchmark ---> benchmark(string, factor, pred).
:- inst benchmark ---> benchmark(ground, ground, (pred) is semidet).

use(_) :- semidet_succeed.

benchmark_list = [
		benchmark("append", 10, append),
		benchmark("mirror", 1, mirror),
		benchmark("nrev", 1, nrev),
		benchmark("rev_dbl", 1, reverse_double),
		benchmark("sumdbl", 10, sumdbl),
		benchmark("sumlist", 100, sumlist)
	].

data([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,
	16,17,18,19,20,21,22,23, 24,25,26,27,28,29,30]).
