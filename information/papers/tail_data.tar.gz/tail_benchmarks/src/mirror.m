:- module mirror.

:- interface.

:- pred mirror is semidet.

:- implementation.

:- import_module mirror_impl, run.
:- import_module list.

mirror :-
	data(D),
	mirror(D, M),
	use(M).
