:- module append.

:- interface.

:- pred append is semidet.

:- implementation.

:- import_module append_impl, run.
:- import_module list.

append :-
	data(D),
	app(D, D, L),
	use(L).
