:- module reverse_double_impl.

:- interface.

:- import_module list, int.

:- pred nrev_dbl(list(int), list(int), list(int)).
:- mode nrev_dbl(in, out, out) is det.

:- implementation.

nrev_dbl([X|L0], L, D) :-
	nrev_dbl(L0, L1, D0), app(L1, [X], L), D = [2*X | D0].
nrev_dbl([], [], []).

:- pred app(list(int), list(int), list(int)).
:- mode app(in, in, out) is det.

app([], L, L).
app([X|L1], L2, [X|L3]) :-	
	app(L1, L2, L3).
