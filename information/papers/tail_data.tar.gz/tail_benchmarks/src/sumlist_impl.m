:- module sumlist_impl.

:- interface.

:- import_module list, int.

:- pred sumlist(list(int), int).
:- mode sumlist(in, out) is det.

:- implementation.

% :- assertion all [A,B,C] ( C = A+B <=> C = B+A ).

sumlist([], 0).
sumlist([H|T], S) :-
	sumlist(T, S0),
	S = S0 + H.
