:- module sumlist.

:- interface.

:- pred sumlist is semidet.

:- implementation.

:- import_module sumlist_impl, run.
:- import_module list.

sumlist :-
	data(D),
	sumlist(D, S),
	use(S).
