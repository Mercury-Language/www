:- module reverse_double.

:- interface.

:- pred reverse_double is semidet.

:- implementation.

:- import_module reverse_double_impl, run.
:- import_module list.

reverse_double :-
	data(D),
	nrev_dbl(D, R, L),
	use(R),
	use(L).
